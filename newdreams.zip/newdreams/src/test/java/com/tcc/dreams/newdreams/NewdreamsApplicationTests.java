package com.tcc.dreams.newdreams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewdreamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
