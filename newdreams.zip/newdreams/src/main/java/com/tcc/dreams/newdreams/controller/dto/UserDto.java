package com.tcc.dreams.newdreams.controller.dto;

import java.time.LocalDate;

public class UserDto {
	
	private Long id;
	private String firstName;
	private String lastName;
	private String cpf;
	private String email;
	private String password;
	private String senhaMobile;
	private LocalDate dataNascimento;
	private String principalRole;
	private String logradouro;
	private String bairro;
	private String cep;
	private String cidade;
	private String uf;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSenhaMobile() {
		return senhaMobile;
	}
	public void setSenhaMobile(String senhaMobile) {
		this.senhaMobile = senhaMobile;
	}
	public LocalDate getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getPrincipalRole() {
		return principalRole;
	}
	public void setPrincipalRole(String principalRole) {
		this.principalRole = principalRole;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	
	

}
