package com.tcc.dreams.newdreams.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tcc.dreams.newdreams.controller.dto.UserDto;
import com.tcc.dreams.newdreams.model.Role;
import com.tcc.dreams.newdreams.model.User;
import com.tcc.dreams.newdreams.model.service.UserService;
import com.tcc.dreams.newdreams.repository.RoleRepository;

@Controller
@RequestMapping("/dreamstourism/users")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	RoleRepository roleRepository;

	@ModelAttribute("user")
	public UserDto userDto() {
		return new UserDto();
	}



	@GetMapping("/home")
	public String homeUser(Model model) {

		String home = "index";

		User user = userService.getAuthenticatedUser();
		String username = user.getEmail();
		model.addAttribute("username", username);

		return home;

	}

}
